# xiaoyouxi

小游戏合集，直接用浏览器打开即可游玩（手机 / 电脑自适应）：

- [霓虹叠塔 · NEON STACK](./index.html) —— 点击或空格落块，在节奏里把光堆成一座塔
- [霓虹漂流 · NEON DRIFT](./neon-drift.html) —— 旧版霓虹街机游戏
- [霓虹脉冲 · NEON PULSE](./neon-pulse.html) —— 赛博朋克极速闪躲，收集晶体 × 躲避激光，支持三档难度与连击倍率

> 🔓 所有游戏共用同一个隐藏作弊码：依次键入 `axisihuairen` 开启作弊模式（无敌 + 自动吸附）
